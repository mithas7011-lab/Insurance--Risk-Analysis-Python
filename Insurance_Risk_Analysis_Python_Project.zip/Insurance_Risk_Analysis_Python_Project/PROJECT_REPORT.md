# Project Report: Insurance Risk Analysis & Premium Prediction

## 1. Introduction
This project demonstrates how Python can support insurance portfolio analysis and an introductory risk-pricing workflow. It uses 5,000 simulated motor-insurance policies.

## 2. Objectives
- Calculate claim frequency, claim severity and pure premium.
- Compare risk measures across coverage categories.
- Build and evaluate a model to estimate annualised claim cost.
- Produce an illustrative premium indication.

## 3. Data and methodology
The dataset contains driver age, vehicle age, annual mileage, region, coverage type, exposure, claim count and total claim amount. The data is synthetic and reproducible. Pandas and NumPy are used for data preparation and actuarial calculations. Matplotlib is used for visualisation. A Random Forest regression pipeline with preprocessing is used for prediction.

## 4. Results
The exact portfolio and model results are saved in `outputs/portfolio_metrics.csv` and `outputs/model_evaluation.csv`. Segment results are in `outputs/risk_by_coverage.csv`. The model is evaluated on a held-out test sample using MAE, RMSE and R-squared.

## 5. Premium indication
The project calculates predicted annual claim cost and applies an assumed 20% loading to produce an illustrative premium indication. This loading is a demonstration assumption only.

## 6. Conclusion
The project connects data analysis, actuarial measures and predictive modelling. It demonstrates a reproducible Python workflow for analysing insurance risk and communicating results through tables and charts.

## 7. Limitations
The dataset is simulated, not sourced from an insurer. Model results cannot be used to price real policies. A real-world application would require validated data, actuarial review, model governance, fairness assessment and regulatory compliance.
