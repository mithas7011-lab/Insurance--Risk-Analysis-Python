# Insurance Risk Analysis & Premium Prediction Using Python

**Portfolio project | Python | Actuarial Analytics | Predictive Modelling**

## Project objective
Analyse a motor-insurance portfolio, calculate core actuarial measures, compare risk across policy segments, and build a machine-learning model to estimate annualised claim costs. The estimated cost is then used to create an illustrative premium indication.

## Tools and libraries
- Python
- Pandas and NumPy
- Matplotlib
- scikit-learn
- CSV data handling

## Dataset
`data/synthetic_motor_insurance_data.csv` contains 5,000 simulated motor-insurance policies. It is generated for learning and portfolio demonstration; it is **not real customer or insurer data**.

## Methodology
1. Inspect the dataset and check for missing values.
2. Calculate exposure, claim frequency, average claim severity and pure premium.
3. Segment the portfolio by coverage type and compare risk.
4. Visualise pure premium and claim totals.
5. Train a Random Forest regression pipeline to estimate annualised claim cost.
6. Evaluate the model using MAE, RMSE and R-squared.
7. Produce an illustrative premium indication using a 20% assumed loading.

## How to run
```bash
pip install -r requirements.txt
python insurance_risk_analysis.py
```

The script writes tables and charts to the `outputs/` folder.

## Key actuarial concepts
- **Exposure:** time for which a policy is at risk, measured in policy-years.
- **Claim frequency:** number of claims divided by exposure.
- **Claim severity:** total claim amount divided by number of claims.
- **Pure premium:** total claim cost divided by exposure.
- **Indicated premium:** expected claim cost plus an assumed loading for expenses, uncertainty and other costs.

## Important limitations
- All records are synthetic and generated using assumptions.
- The model is an educational demonstration, not a production pricing model.
- The 20% loading is an illustrative assumption, not a market or regulatory recommendation.
- Real pricing requires validated insurer data, credibility analysis, reserving considerations, fairness testing, regulatory review and actuarial judgement.
- Random Forest predictions may be affected by the many zero-claim policies and the skewed distribution of claim costs. Model metrics should be interpreted in that context.

## Suggested resume entry
**Insurance Risk Analysis & Premium Prediction | Python**
- Analysed a simulated portfolio of 5,000 motor-insurance policies using Python, Pandas and NumPy.
- Calculated claim frequency, average severity and pure premium, and compared risk across coverage segments.
- Developed a Random Forest regression pipeline to estimate annualised claim costs and evaluated performance using MAE, RMSE and R-squared.
- Created data visualisations and an illustrative risk-based premium output.

*Replace the project title or bullets only if they accurately reflect the work you have completed and can explain in an interview.*
