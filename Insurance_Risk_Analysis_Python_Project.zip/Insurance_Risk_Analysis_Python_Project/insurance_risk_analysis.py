"""
Insurance Risk Analysis & Premium Prediction
Author: [Your Name]
Note: Uses a clearly labelled synthetic dataset for portfolio demonstration.
Run: python insurance_risk_analysis.py
"""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data" / "synthetic_motor_insurance_data.csv"
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)

df = pd.read_csv(DATA)

# 1. Data quality checks
print("DATA OVERVIEW")
print(df.head())
print("\nDataset shape:", df.shape)
print("\nMissing values:\n", df.isna().sum())
print("\nDescriptive statistics:\n", df.select_dtypes(include=["number"]).describe().round(2))

# 2. Portfolio-level actuarial metrics
total_exposure = df["exposure_years"].sum()
total_claims = df["claim_count"].sum()
total_losses = df["total_claim_amount"].sum()
frequency = total_claims / total_exposure
severity = total_losses / total_claims if total_claims else 0
pure_premium = total_losses / total_exposure

metrics = pd.DataFrame({
    "Metric": ["Policies", "Total exposure (policy-years)", "Total claims",
               "Total incurred claims", "Claim frequency per policy-year",
               "Average claim severity", "Pure premium per policy-year"],
    "Value": [len(df), total_exposure, total_claims, total_losses,
              frequency, severity, pure_premium]
})
metrics.to_csv(OUT / "portfolio_metrics.csv", index=False)
print("\nPORTFOLIO METRICS\n", metrics.to_string(index=False))

# 3. Risk segmentation
seg = (df.groupby("coverage_type")
       .agg(policies=("policy_id", "count"),
            exposure=("exposure_years", "sum"),
            claims=("claim_count", "sum"),
            losses=("total_claim_amount", "sum"))
       .reset_index())
seg["claim_frequency"] = seg["claims"] / seg["exposure"]
seg["average_severity"] = np.where(seg["claims"] > 0, seg["losses"] / seg["claims"], 0)
seg["pure_premium"] = seg["losses"] / seg["exposure"]
seg.to_csv(OUT / "risk_by_coverage.csv", index=False)

# 4. Visualisations
plt.figure(figsize=(8, 5))
seg.plot(x="coverage_type", y="pure_premium", kind="bar", legend=False,
         color="steelblue", title="Pure Premium by Coverage Type")
plt.ylabel("Losses per exposure year")
plt.xlabel("Coverage type")
plt.tight_layout()
plt.savefig(OUT / "pure_premium_by_coverage.png", dpi=160)
plt.close()

region_loss = df.groupby("region")["total_claim_amount"].sum().sort_values(ascending=False)
plt.figure(figsize=(7, 5))
region_loss.plot(kind="bar", title="Total Claims by Region", color="slateblue")
plt.ylabel("Total claim amount")
plt.xlabel("Region")
plt.tight_layout()
plt.savefig(OUT / "claims_by_region.png", dpi=160)
plt.close()

# 5. Predict annualised claim cost per policy-year
# Target is annualised loss cost; exposure is used to annualise observed claims.
model_df = df.copy()
model_df["annualised_claim_cost"] = model_df["total_claim_amount"] / model_df["exposure_years"]
features = ["driver_age", "vehicle_age", "annual_mileage", "region", "coverage_type"]
X = model_df[features]
y = model_df["annualised_claim_cost"]

numeric = ["driver_age", "vehicle_age", "annual_mileage"]
categorical = ["region", "coverage_type"]
preprocess = ColumnTransformer([
    ("num", StandardScaler(), numeric),
    ("cat", OneHotEncoder(handle_unknown="ignore"), categorical)
])
model = Pipeline([
    ("preprocess", preprocess),
    ("regressor", RandomForestRegressor(n_estimators=180, min_samples_leaf=5,
                                        random_state=42, n_jobs=-1))
])

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)
model.fit(X_train, y_train)
pred = model.predict(X_test)
mae = mean_absolute_error(y_test, pred)
rmse = np.sqrt(mean_squared_error(y_test, pred))
r2 = r2_score(y_test, pred)

evaluation = pd.DataFrame({
    "Metric": ["MAE", "RMSE", "R-squared"],
    "Value": [mae, rmse, r2]
})
evaluation.to_csv(OUT / "model_evaluation.csv", index=False)
print("\nMODEL EVALUATION\n", evaluation.to_string(index=False))

# 6. Illustrative risk-based premium indication
# Expected loss cost + 20% illustrative expense/risk loading.
# This is a teaching assumption, not a real-world tariff.
predicted_cost = np.maximum(model.predict(X), 0)
pricing = df[["policy_id", "region", "coverage_type"]].copy()
pricing["predicted_annual_claim_cost"] = predicted_cost
pricing["illustrative_indicated_premium"] = predicted_cost * 1.20
pricing.to_csv(OUT / "illustrative_policy_premiums.csv", index=False)

print("\nFiles saved in:", OUT)
print("Important: results are illustrative and based on synthetic data.")
